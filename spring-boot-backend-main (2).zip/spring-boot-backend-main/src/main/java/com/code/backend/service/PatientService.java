package com.code.backend.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.code.backend.exception.ResourceNotFoundException;
import com.code.backend.model.Patient;
import com.code.backend.repository.PatientRepo;

@Service
public class PatientService {
	
	private PatientRepo patientRepo;
	
	public PatientService(PatientRepo patientRepo) {
		this.patientRepo = patientRepo;
	}

	public Patient savePatient(Patient Patient) {
		return patientRepo.save(Patient);
	}
	
	public List<Patient> getPatients() {
		return patientRepo.findAll();
	}
	
	public Patient getPatientById(long id) {
		Optional<Patient> Patient = patientRepo.findById(id);
		if (Patient.isPresent()) {
			return Patient.get();
		} else {
			//return null;
			throw new ResourceNotFoundException("Patient", "Id", id);
		}
	}
	
	public Patient updatePatient(Patient Patient, long id) {
		Patient existingPatient = patientRepo.findById(id).orElseThrow(
					() -> new ResourceNotFoundException("Patient", "Id", id)
				);
		existingPatient.setFirstName(Patient.getFirstName());
		existingPatient.setInsuranceNo(Patient.getInsuranceNo());
		existingPatient.setDiagnose(Patient.getDiagnose());
		existingPatient.setLastName(Patient.getLastName());
		patientRepo.save(existingPatient);
		return existingPatient;
	}
	
	public void deletePatient(long id) {
		patientRepo.findById(id).orElseThrow(
				() -> new ResourceNotFoundException("Patient", "Id", id)
			);
		patientRepo.deleteById(id);
	}

}
