package com.code.backend.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.code.backend.exception.ResourceNotFoundException;
import com.code.backend.model.Doctor;
import com.code.backend.repository.DoctorRepo;

@Service
public class DoctorService {
	
	private DoctorRepo doctorRepo;
	
	public DoctorService(DoctorRepo doctorRepo) {
		this.doctorRepo = doctorRepo;
	}

	public Doctor saveDoctor(Doctor doctor) {
		return doctorRepo.save(doctor);
	}
	
	public List<Doctor> getDoctors() {
		return doctorRepo.findAll();
	}
	
	public Doctor getDoctorById(long id) {
		Optional<Doctor> doctor = doctorRepo.findById(id);
		if (doctor.isPresent()) {
			return doctor.get();
		} else {
			//return null;
			throw new ResourceNotFoundException("Doctor", "Id", id);
		}
	}
	
	public Doctor updateDoctor(Doctor Doctor, long id) {
		Doctor existingDoctor = doctorRepo.findById(id).orElseThrow(
					() -> new ResourceNotFoundException("Doctor", "Id", id)
				);
		existingDoctor.setFirstName(Doctor.getFirstName());
		existingDoctor.setSpecialization(Doctor.getSpecialization());
		existingDoctor.setLastName(Doctor.getLastName());
		doctorRepo.save(existingDoctor);
		return existingDoctor;
	}
	
	public void deleteDoctor(long id) {
		doctorRepo.findById(id).orElseThrow(
				() -> new ResourceNotFoundException("Doctor", "Id", id)
			);
		doctorRepo.deleteById(id);
	}

}
