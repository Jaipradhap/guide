package com.code.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.code.backend.model.Patient;
import com.code.backend.service.PatientService;
import javax.validation.Valid;

@RestController
@RequestMapping("/api/patient")
public class PatientController {
	
	@Autowired
	private PatientService patientService;

	// Create
	@PostMapping("/addPatient")
	public ResponseEntity<Patient> savePatient(@RequestBody @Valid Patient patient) {
		System.out.println(patient);
		Patient doc = patientService.savePatient(patient);
		return new ResponseEntity<Patient>(doc, HttpStatus.CREATED);
	} 
	
	// Read
	@GetMapping
	public List<Patient> getPatients() {
		return patientService.getPatients();
	}
	
	@GetMapping("{id}")
	public ResponseEntity<Patient> getPatientById(@PathVariable long id) {
		Patient patient = patientService.getPatientById(id);
		return new ResponseEntity<Patient>(patient, HttpStatus.OK);
	}
	
	// Update
	@PutMapping("{id}")
	public ResponseEntity<Patient> updatePatient(@PathVariable("id") long id, @RequestBody @Valid Patient patient) {
		Patient doc = patientService.updatePatient(patient, id);
		return new ResponseEntity<Patient>(doc, HttpStatus.OK);
	}
	
	// Delete
	@DeleteMapping("{id}")
	public ResponseEntity<String> deletePatient(@PathVariable("id") long id) {
		patientService.deletePatient(id);
		return new ResponseEntity<String>("Patient deleted succesfully", HttpStatus.OK);
	}
}