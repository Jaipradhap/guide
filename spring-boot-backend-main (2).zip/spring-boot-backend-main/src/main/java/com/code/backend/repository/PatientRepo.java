package com.code.backend.repository;

import com.code.backend.model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PatientRepo extends JpaRepository<Patient, Long>{

}
