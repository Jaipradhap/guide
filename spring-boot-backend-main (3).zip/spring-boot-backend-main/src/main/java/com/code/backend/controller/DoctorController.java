package com.code.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.code.backend.model.Doctor;
import com.code.backend.service.DoctorService;
import javax.validation.Valid;

@RestController
@RequestMapping("/api/doctor")
public class DoctorController {
	
	@Autowired
	private DoctorService doctorService;

	// Create
	@PostMapping("/addDoctor")
	public ResponseEntity<Doctor> saveDoctor(@RequestBody @Valid Doctor doctor) {
		System.out.println(doctor);
		Doctor doc = doctorService.saveDoctor(doctor);
		return new ResponseEntity<Doctor>(doc, HttpStatus.CREATED);
	} 
	
	// Read
	@GetMapping
	public List<Doctor> getDoctors() {
		return doctorService.getDoctors();
	}
	
	@GetMapping("{id}")
	public ResponseEntity<Doctor> getDoctorById(@PathVariable long id) {
		Doctor doctor = doctorService.getDoctorById(id);
		return new ResponseEntity<Doctor>(doctor, HttpStatus.OK);
	}
	
	// Update
	@PutMapping("{id}")
	public ResponseEntity<Doctor> updateDoctor(@PathVariable("id") long id, @RequestBody @Valid Doctor doctor) {
		Doctor doc = doctorService.updateDoctor(doctor, id);
		return new ResponseEntity<Doctor>(doc, HttpStatus.OK);
	}
	
	// Delete
	@DeleteMapping("{id}")
	public ResponseEntity<String> deleteDoctor(@PathVariable("id") long id) {
		doctorService.deleteDoctor(id);
		return new ResponseEntity<String>("Doctor deleted succesfully", HttpStatus.OK);
	}
}